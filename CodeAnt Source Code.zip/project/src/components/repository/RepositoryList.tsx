import React from 'react';
import { Repository } from '../../types/auth';
import { GitBranch, Star } from 'lucide-react';

const mockRepositories: Repository[] = [
  {
    id: '1',
    name: 'web-crawler',
    description: 'A fast and efficient web crawler built with Python',
    language: 'Python',
    lastUpdated: '2024-03-10',
    stars: 128
  },
  {
    id: '2',
    name: 'react-components',
    description: 'A collection of reusable React components',
    language: 'TypeScript',
    lastUpdated: '2024-03-09',
    stars: 256
  },
  {
    id: '3',
    name: 'ml-algorithms',
    description: 'Implementation of common machine learning algorithms',
    language: 'Python',
    lastUpdated: '2024-03-08',
    stars: 512
  }
];

export const RepositoryList: React.FC = () => {
  return (
    <div className="space-y-4">
      {mockRepositories.map((repo) => (
        <div
          key={repo.id}
          className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
        >
          <div className="flex items-start justify-between">
            <div>
              <h3 className="text-xl font-semibold text-blue-600">
                {repo.name}
              </h3>
              <p className="mt-1 text-gray-600">{repo.description}</p>
              <div className="mt-4 flex items-center space-x-4">
                <span className="flex items-center text-sm text-gray-500">
                  <div className="w-3 h-3 rounded-full bg-yellow-400 mr-2" />
                  {repo.language}
                </span>
                <span className="flex items-center text-sm text-gray-500">
                  <Star className="w-4 h-4 mr-1" />
                  {repo.stars}
                </span>
                <span className="flex items-center text-sm text-gray-500">
                  <GitBranch className="w-4 h-4 mr-1" />
                  Updated {repo.lastUpdated}
                </span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};