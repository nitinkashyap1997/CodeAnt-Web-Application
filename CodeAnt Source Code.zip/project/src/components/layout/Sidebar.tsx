import React from 'react';
import { 
  Home,
  FolderGit2,
  Bot,
  Shield,
  HelpCircle,
  Settings
} from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const navItems = [
  { icon: FolderGit2, label: 'Repositories', path: '/repository' },
  { icon: Bot, label: 'AI Code Review', path: '/code-review' },
  { icon: Shield, label: 'Cloud Security', path: '/security' },
  { icon: HelpCircle, label: 'How to use', path: '/guide' },
  { icon: Settings, label: 'Settings', path: '/settings' },
];

export const Sidebar: React.FC = () => {
  const location = useLocation();

  return (
    <div className="w-64 bg-white border-r border-gray-200 h-screen fixed left-0 top-16">
      <nav className="p-4 space-y-2">
        {navItems.map(({ icon: Icon, label, path }) => (
          <Link
            key={path}
            to={path}
            className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
              location.pathname === path
                ? 'bg-blue-50 text-blue-600'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            <Icon className="w-5 h-5" />
            <span className="font-medium">{label}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
};