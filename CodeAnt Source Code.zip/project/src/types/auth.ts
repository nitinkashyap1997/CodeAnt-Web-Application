export interface User {
  email: string;
  password: string;
}

export interface Repository {
  id: string;
  name: string;
  description: string;
  language: string;
  lastUpdated: string;
  stars: number;
}