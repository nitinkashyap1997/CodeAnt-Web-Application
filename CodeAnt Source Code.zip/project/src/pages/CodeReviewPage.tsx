import React from 'react';
import { DashboardLayout } from '../components/layout/DashboardLayout';

export const CodeReviewPage: React.FC = () => {
  return (
    <DashboardLayout title="AI Code Review">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <p className="text-gray-600">AI-powered code review features coming soon...</p>
      </div>
    </DashboardLayout>
  );
};