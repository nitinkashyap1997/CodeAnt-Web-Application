import React from 'react';
import { DashboardLayout } from '../components/layout/DashboardLayout';

export const GuidePage: React.FC = () => {
  return (
    <DashboardLayout title="How to use CodeAnt">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <p className="text-gray-600">Documentation and guides coming soon...</p>
      </div>
    </DashboardLayout>
  );
};