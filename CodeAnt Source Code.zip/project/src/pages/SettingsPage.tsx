import React from 'react';
import { DashboardLayout } from '../components/layout/DashboardLayout';

export const SettingsPage: React.FC = () => {
  return (
    <DashboardLayout title="Settings">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <p className="text-gray-600">Account and application settings coming soon...</p>
      </div>
    </DashboardLayout>
  );
};