import React from 'react';
import { RepositoryList } from '../components/repository/RepositoryList';
import { DashboardLayout } from '../components/layout/DashboardLayout';
import { Button } from '../components/ui/Button';

export const RepositoryPage: React.FC = () => {
  return (
    <DashboardLayout title="Your Repositories">
      <div className="flex justify-end mb-8">
        <Button>New Repository</Button>
      </div>
      <RepositoryList />
    </DashboardLayout>
  );
};