import React from 'react';
import { DashboardLayout } from '../components/layout/DashboardLayout';

export const SecurityPage: React.FC = () => {
  return (
    <DashboardLayout title="Cloud Security">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <p className="text-gray-600">Cloud security features and monitoring coming soon...</p>
      </div>
    </DashboardLayout>
  );
};